<?php
// vim: foldmethod=marker

/* Generic exception class
 */
if(!class_exists("OAuthException") ) {
	class OAuthException extends Exception {
	  // pass
	}
}

?>